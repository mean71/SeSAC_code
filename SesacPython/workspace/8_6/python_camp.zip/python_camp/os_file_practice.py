# --------------------------------------------
# 1. os 활용 예제 
# 
# 1) os 디렉토리 구조 출력해보기 
# 2) root directory 아래에 있는 특정 확정자 파일들 다 출력하기 
# 3) os 디렉토리 복사하기 
# --------------------------------------------

def print_directory_tree(root):
    """
    """

def list_extension_files(root):
    pass 

def copy_directory(src, dest):
    pass

    